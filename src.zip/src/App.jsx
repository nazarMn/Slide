
import './App.css'
import MySlider from './components/Slider/MySlider'

function App() {


  return (
    <>
      <h1>Slider</h1>
      <MySlider />

    </>
  )
}

export default App
