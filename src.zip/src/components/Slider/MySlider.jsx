import React from 'react'
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
export default function MySlider() {
    const slides = [
        { id: 1, image: "https://via.placeholder.com/800x300?text=Слайд+1", title: "Слайд 1" },
        { id: 2, image: "https://via.placeholder.com/800x300?text=Слайд+2", title: "Слайд 2" },
        { id: 3, image: "https://via.placeholder.com/800x300?text=Слайд+3", title: "Слайд 3" },
        { id: 4, image: "https://via.placeholder.com/800x300?text=Слайд+4", title: "Слайд 4" },
        { id: 5, image: "https://via.placeholder.com/800x300?text=Слайд+5", title: "Слайд 5" },
    ];

    const settigs = {
        dots: true,
        infite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoPlay: true,
        autoPlaySpeed: 3000
    };
    return (
        <Slider {...settigs}>
            {slides.map((slide) => (
                <div key={slide.id}>
                    <img src={slide.image} alt={slide.title} />
                    <h3>{slide.title}</h3>
                </div>
            ))}
        </Slider>
    )
}
